# mypackage
An example on publishing my own Python package